# Signal Bread Interactive

Official website for Signal Bread Interactive.

Current GitHub Pages URL:
`https://tomcdiver.github.io/supercooltaxfraud/`

Planned custom domain:
`https://taxfraud.lol`

## Files
- `index.html` — main site
- `styles.css` — full design
- `script.js` — mobile navigation, footer year, reveal animations

The site uses only relative asset paths so it works both from the GitHub Pages project URL and from a custom domain.
